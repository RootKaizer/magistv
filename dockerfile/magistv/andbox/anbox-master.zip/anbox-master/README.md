## IMPORTANT - Hi there 👋


The Anbox project [was once ago created in 2017](https://www.omgubuntu.co.uk/2017/04/android-apps-linux-desktop-anbox) to bring Android to any Linux based desktop operating system. It's development has however stalled in the past years and it's only fair to say that now in 2023 it's no longer actively developed.

In the past years new alternatives have came up which are carrying the same idea of a containerized Android forward:

If you're looking for a solution to run Android on your Linux desktop:

* [Waydroid](https://waydro.id/) is rebuilding the original idea behind Anbox with explicit focus on modern [Wayland](https://wayland.freedesktop.org/) powered desktop environments.

If you're looking for a solution to run Android in the cloud:

* [Anbox Cloud](https://anbox-cloud.io) as a solution developed by [Canonical](https://canonical.com), the company behind [Ubuntu](https://ubuntu.com), to bring Android at scale to any cloud with support for ultra low latency video streaming and recent Android versions.

The existing repositories will remain as is but no active maintence will be applied going forward.

*Thank you all for your support!*

----

# Anbox

Anbox is a container-based approach to boot a full Android system on a
regular GNU/Linux system like Ubuntu. In other words: Anbox will let
you run Android on your Linux system without the slowness of
virtualization.

## Overview

Anbox uses Linux namespaces (user, pid, uts, net, mount, ipc) to run a
full Android system in a container and provide Android applications on
any GNU/Linux-based platform.

The Android inside the container has no direct access to any hardware.
All hardware access is going through the anbox daemon on the host. We're
reusing what Android implemented within the QEMU-based emulator for OpenGL
ES accelerated rendering. The Android system inside the container uses
different pipes to communicate with the host system and sends all hardware
access commands through these.

For more details have a look at the following documentation pages:

 * [Android Hardware OpenGL ES emulation design overview](https://android.googlesource.com/platform/external/qemu/+/emu-master-dev/android/android-emugl/DESIGN)
 * [Android QEMU fast pipes](https://android.googlesource.com/platform/external/qemu/+/emu-master-dev/android/docs/ANDROID-QEMU-PIPE.TXT)
 * [The Android "qemud" multiplexing daemon](https://android.googlesource.com/platform/external/qemu/+/emu-master-dev/android/docs/ANDROID-QEMUD.TXT)
 * [Android qemud services](https://android.googlesource.com/platform/external/qemu/+/emu-master-dev/android/docs/ANDROID-QEMUD-SERVICES.TXT)

Anbox is currently suited for the desktop use case but can be used on mobile
operating systems like [Ubuntu Touch](https://ubuntu-touch.io/) or
[postmarketOS](https://postmarketos.org)
([installation instructions](https://wiki.postmarketos.org/wiki/Anbox)).
However this is still a work in progress.

The Android runtime environment ships with a minimal customized Android system
image based on the [Android Open Source Project](https://source.android.com/).
The used image is currently based on Android 7.1.1

## Installation

See our [installation instructions](docs/install.md) for details.

## Supported Linux Distributions

At the moment we officially support the following Linux distributions:

 * Ubuntu 18.04 (bionic)
 * Ubuntu 20.04 (focal)

However all other distributions supporting snap packages should work as
well as long as they provide the mandatory kernel support (see [documentation](docs/install.md)).

## Install and Run Android Applications

You can install Android applications from the command line using adb.

```sh
adb install xyz.apk
```

The apk files you will sometimes find on the internet tend to only have arm
support, and will therefore not work on x86\_64.

You may want to install [F-Droid](https://f-droid.org/) to get applications
graphically. Note that the Google Play Store will not work as is, because it
relies on the proprietary Google Play Services, which are not installed.

## Build from source

### Requirements

To build the Anbox runtime itself there is nothing special to know. We're using
cmake as build system. A few build dependencies need to be present on your host
system:

 * libdbus
 * google-mock
 * google-test
 * libboost
 * libboost-filesystem
 * libboost-log
 * libboost-iostreams
 * libboost-program-options
 * libboost-system
 * libboost-test
 * libboost-thread
 * libcap
 * libexpat1-dev
 * libsystemd
 * mesa (libegl1, libgles2)
 * libglm
 * libsdl2
 * libprotobuf
 * protobuf-compiler
 * python3
 * lxc (>= 3.0)

On an Ubuntu system you can install all build dependencies with the following
command:

```
$ sudo apt install build-essential cmake cmake-data debhelper dbus google-mock \
    libboost-dev libboost-filesystem-dev libboost-log-dev libboost-iostreams-dev \
    libboost-program-options-dev libboost-system-dev libboost-test-dev \
    libboost-thread-dev libcap-dev libexpat1-dev libsystemd-dev libegl1-mesa-dev \
    libgles2-mesa-dev libglm-dev libgtest-dev liblxc1 \
    libproperties-cpp-dev libprotobuf-dev libsdl2-dev libsdl2-image-dev lxc-dev \
    pkg-config protobuf-compiler python3-minimal
```
We recommend Ubuntu 20.04 (focal) as your build environment.


### Build

Afterwards you can build Anbox with

```
$ git clone https://github.com/anbox/anbox.git --recurse-submodules
$ cd anbox
$ mkdir build
$ cd build
$ cmake ..
$ make
```

A simple

```
$ sudo make install
```

will install the necessary bits into your system.

If you want to build the anbox snap instead you can do this with the following
steps:

```
$ ARCH=$(uname -m)
$ cp /path/to/android.img data/android-images/android-$ARCH.img
$ snapcraft
```

The result will be a .snap file you can install on a system supporting snaps

```
$ snap install --dangerous --devmode anbox_1_amd64.snap
```

## Run Anbox

Running Anbox from a local build requires a few more things you need to know
about. Please have a look at the ["Runtime Setup"](docs/runtime-setup.md)
documentation.

## Documentation

You will find additional documentation for Anbox in the *docs* subdirectory
of the project source.

Interesting things to have a look at

 * [Runtime Setup](docs/runtime-setup.md)
 * [Build Android image](docs/build-android.md)
 * [Generate Android emugl source](docs/generate-emugl-source.md)
 * [DBUS interface](docs/dbus.md)

## Reporting bugs

If you have found an issue with Anbox, please [file a bug](https://github.com/anbox/anbox/issues/new).

## Get in Touch

If you want to get in contact with the developers please feel free to join the
*#anbox* IRC channel on [Libera.Chat](https://libera.chat).

## Copyright and Licensing

Anbox reuses code from other projects like the Android QEMU emulator. These
projects are available in the external/ subdirectory with the licensing terms
included.

The Anbox source itself, if not stated differently in the relevant source files,
is licensed under the terms of the GPLv3 license.
