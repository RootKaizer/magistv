You can put your own android images here. They will be used
when building the snap.

You should name your images `android-$(arch).img`. For example
`android-x86_64.img` or `android-aarch64.img`.
